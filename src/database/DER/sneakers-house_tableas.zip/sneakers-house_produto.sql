-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sneakers-house
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `produto`
--

DROP TABLE IF EXISTS `produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sku` varchar(45) DEFAULT NULL,
  `marca` varchar(45) DEFAULT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `imagemDestaque` varchar(100) DEFAULT NULL,
  `imagem` varchar(150) DEFAULT NULL,
  `cor` varchar(45) DEFAULT NULL,
  `valor` decimal(10,2) DEFAULT NULL,
  `desconto` decimal(10,2) DEFAULT NULL,
  `descricao` varchar(1000) DEFAULT NULL,
  `tamanho` enum('34','35','36','37','38','39','40','41','42','43') DEFAULT NULL,
  `destaque` tinyint DEFAULT NULL,
  `oferta` tinyint DEFAULT NULL,
  `id_produto_categoria` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_produto_categoria_idx` (`id_produto_categoria`),
  CONSTRAINT `fk_produto_categoria_idx` FOREIGN KEY (`id_produto_categoria`) REFERENCES `produto_categoria` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produto`
--

LOCK TABLES `produto` WRITE;
/*!40000 ALTER TABLE `produto` DISABLE KEYS */;
INSERT INTO `produto` VALUES (1,'BBW550BC','NewBalance','New Balance 550 UNC','new-balance-550-01.png','new-balance-550-01.png','multicolor',399.90,299.90,'O Tênis New Balance 550 homenageia o calçado original de basquete criado em 1989, época que definiu uma geração de atletas da modalidade. O modelo oferece fechamento em cadarço para um ajuste seguro e traz originalidade aos looks casuais.','34',1,0,1),(2,'DV5255500','Nike','UNDEFEATED x Nike Air Force 1','nike-undefeated-01.png','nike-undefeated-01.png','multicolor',299.90,199.90,'Dark Marina Blue, Sangria e Pinksicle se unem em um rico couro envernizado neste tênis de colaboração. E nós mencionamos que não há 2 painéis iguais? A parte superior multicolorida fica no topo de uma entressola branca e é amarrada por um Swoosh laranja. Uma etiqueta de língua tecida laranja e vermelha serve como um aceno para um lançamento inicial do UNDEFEATED, enquanto uma impressão total na palmilha fornece um detalhe oculto. Para finalizar o visual, há um gráfico 5 Strikes sutil e gravado no calcanhar e um dubrae UNDFTD fácil de remover - que é exclusivo desta silhueta.','35',1,0,1),(3,'DR0156300','Nike','Nike Dunk Low Safari Swoosh','nike-dunk-low-safari-01.png','nike-dunk-low-safari-02.png','verde',599.90,299.90,'Criado para as quadras, mas conquistou as ruas, o ícone do basquete dos anos 80 retorna com detalhes clássicos e um toque retrô. As sobreposições de camurça flexível ajudam o estilo vintage do Dunk Low, enquanto os logotipos Swoosh estampados em negrito adicionam um toque selvagem. Além disso, o colarinho acolchoado de baixo perfil mantém você confortável em qualquer lugar.','37',1,0,2),(4,'1201A516300','Asics','Sneaker Politics x Asics Gel Lyte','sneaker-politics-x-asics-01.png','sneaker-politics-x-asics-01.png','verde',599.90,299.90,'A ASICS e a Sneaker Politics apresentam os detalhes do novo GEL-LYTE III ‘Always Ready’, a mais nova colaboração entre as marcas e que chega ao mercado a partir de amanhã, 11 de junho. O design foi inspirado no exército dos EUA e a criação é uma forma de agradecimento aos soldados americanos. Em 1999, o fundador da Sneaker Politics, Derek Curry, entrou para o exército e foi escolhido para passar nove meses no Iraque, em 2003. Curry deve muito do seu sucesso profissional aos aprendizados e valores que aprendeu enquanto serviu ao exército.','37',1,0,2),(5,'1201A871961','Asics','Asics Gel-Lyte V Pink Aqua Multicolor','AsicsGel-LyteVPink-01.png','AsicsGel-LyteVPink-01.png','multicolor',399.90,299.00,'O tênis GEL-LYTE® V se inspira na ideia de descartar o conteúdo do chão de uma sala de edição e usá-lo para criar algo novo.','36',0,1,3),(6,'HP9782','Adidas','Adidas Orketro 2.0 Blue Bird','adidasOrketro-01.png','adidasOrketro-01.png','multicolor',299.90,199.00,'O adidas Orketro retrocede até pouco antes do século 21, quando a inovação em tênis leves de corrida decolou. Esta atualização oferece um forro confortável e uma parte superior macia que acompanha uma sola de borracha para estabilidade e aderência.','36',0,1,3),(7,'U9060FNB','New Balance','New Balance 9060 Blue Haze','NewBalanceBlueHaze-01.png','NewBalanceBlueHaze-01.png','azul claro',599.90,299.90,'Vestido com um bloco de cores Blue Haze e Turtledove. Esta oferta do New Balance 9060 vem construída em uma mistura de materiais de malha, camurça e couro. Outros detalhes incluem logotipos “N” bordados na parte central sobre uma sola de borracha de dois tons para completar o design.','38',0,0,4),(8,'DV3888600','Nike','Nike Air Max 1 87 Burgundy Crush','nike-air-max-burgundy-crush-01.png','nike-air-max-burgundy-crush-01.png','marrom',599.90,299.00,'Fascínio: a qualidade de usar este Air Max 1 feito à mão. Feito de couro premium, ferragens douradas metálicas e um forro incrivelmente macio, eles são a nova definição de estilo. A marca elevada refina o seu ajuste, enquanto a janela Air cristalina (inspirada na arquitetura francesa e celebrada pelo esporte e pela moda) permite que você veja o mundo do conforto. Amarre, porque não há como conter seu próximo movimento.','36',0,1,4),(9,'LAL10292','Adidas','Adidas Forum Bold','tenis-principal-vect.png','tenis-principal-vect.png','roxo',599.90,299.00,'Fascínio: a qualidade de usar este Air Max 1 feito à mão. Feito de couro premium, ferragens douradas metálicas e um forro incrivelmente macio, eles são a nova definição de estilo. A marca elevada refina o seu ajuste, enquanto a janela Air cristalina (inspirada na arquitetura francesa e celebrada pelo esporte e pela moda) permite que você veja o mundo do conforto. Amarre, porque não há como conter seu próximo movimento.','40',0,1,5),(10,'LAL102323','Nike','Nike SB Dunk High','nike_sb_dunk-high.png','nike_sb_dunk-high.png','laranja',899.90,719.00,'Vestido em camurça e amostras de couro premium de University Gold, Vivid Sulphur e Citron Tint, o -Pineapple- SB Dunk High vem em um sabor brilhante e suculento para os dias mais ensolarados que virão.','40',0,0,5),(11,'LAL131313','Vans','Old Skool VANS X COBRA KAI','vans_cobra-kai.png','vans_cobra-kai_02.png','preto',699.00,599.00,'Vans e Cobra Kai se uniram para uma coleção que celebra o karatê, a nostalgia e a juventude. Com as rivalidades esquentando na 5ª temporada, a Vans criou silhuetas clássicas da Vans para homenagear três dojos competindo no All-Valley Karate Championship. Quem será seu sensei?','39',0,0,5),(12,'BHL1316','Puma','Puma MAYZE UT POP','mayze-ut-pop_03.png','mayze-ut-pop_02.png','branco',699.00,599.00,'Para as garotas hype, as entusiastas das ruas, as criadoras de tendências – apresentamos o Mayze. Este modelo tem uma sola robusta para um visual que mostra quem você é, independentemente do estilo que você escolher.','35',0,0,2),(13,'MNA2316','Puma','Puma Velocity Nitro','puma_velocity-nitro_p.png','puma_velocity-nitro_02.png','azul',999.00,899.00,'Inovador e extremamente confortável, o tênis Velocity Nitro 2 Running chegou para ser o seu mais novo parceiro de corrida.','36',0,0,1),(14,'ANA361609','Puma','RS-X SKELETOR PUMA X HE-MAN','puma-x-he-man_p.png','puma-x-he-man_02.png','roxo',899.00,799.00,'Para comemorar o 40º aniversário da clássica série He-Man e os Defensores do Universo, essa versão do RS-X homenageia o principal antagonista do super-herói: Skeletor.','37',0,0,3),(15,'LLL8764783','Adidas','Adidas NMD_R1','nmd_adidas.png','nmd_adidas_02.png','rosa',899.00,799.00,'Com este tênis Adidas NMR1, você tem um outro tipo de conforto, além de um visual que pode ser combinado com qualquer look','38',0,0,4);
/*!40000 ALTER TABLE `produto` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-14 10:39:39
